
/*GROUP MEMBERS
1. MICHAEL ONGILI- CCS/00069/024
2. INDAH BENEBET BREND- CCS/00080/024
3. CHARLES OTIENO ODUOR-TMC/00033/024
*/

package smartbizz;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

//below is the database code for all the tbles;

/*

CREATE TABLE IF NOT EXISTS users (
    username VARCHAR(50) PRIMARY KEY,
    password VARCHAR(50) NOT NULL,
    role VARCHAR(20) NOT NULL
);

Insert default admin user
INSERT IGNORE INTO users VALUES ('admin', 'admin123', 'Admin');

2. Create Products Table (Inventory)
CREATE TABLE IF NOT EXISTS products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    category VARCHAR(50),
    quantity INT DEFAULT 0,
    price DOUBLE DEFAULT 0.0,
    min_stock_level INT DEFAULT 5
);

3. Create Customers Table
CREATE TABLE IF NOT EXISTS customers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    phone VARCHAR(20),
    email VARCHAR(100)
);

 4. Create Sales Table
CREATE TABLE IF NOT EXISTS sales (
    id INT AUTO_INCREMENT PRIMARY KEY,
    product_id INT,
    quantity INT,
    total_price DOUBLE,
    customer_id INT,
    sale_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (product_id) REFERENCES products(id)
);

5. Create Expenses Table
CREATE TABLE IF NOT EXISTS expenses (
    id INT AUTO_INCREMENT PRIMARY KEY,
    category VARCHAR(50),
    amount DOUBLE,
    description VARCHAR(255),
    expense_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
*/

public class SmartBizz {

    public static void main(String[] args) {
        // Initialize Database
        DatabaseHelper.initDatabase();
        
        // Launch Login Screen
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new LoginFrame().setVisible(true);
            }
        });
    }

    // ==========================================
    // DATABASE HELPER
    // ==========================================
    public static class DatabaseHelper {
        
        // Auto-create database if it doesn't exist
        private static final String URL = "jdbc:mysql://localhost:3306/smartbizz?createDatabaseIfNotExist=true";
        private static final String USER = "root";
        private static final String PASSWORD = "";

        public static Connection getConnection() throws SQLException {
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
            } catch (ClassNotFoundException e) {
                try {
                    Class.forName("com.mysql.jdbc.Driver");
                } catch (ClassNotFoundException ex) {
                    JOptionPane.showMessageDialog(null, "MySQL Driver not found! Add library.");
                    ex.printStackTrace();
                    return null;
                }
            }
            return DriverManager.getConnection(URL, USER, PASSWORD);
        }

        public static void initDatabase() {
            try (Connection con = getConnection()) {
                if (con == null) return;
                
                Statement st = con.createStatement();
                
                // 1. Users Table
                st.execute("CREATE TABLE IF NOT EXISTS users (" +
                        "username VARCHAR(50) PRIMARY KEY, " +
                        "password VARCHAR(50) NOT NULL, " +
                        "role VARCHAR(20) NOT NULL)"); // Roles: 'Admin', 'User'

                // Create default admin if not exists
                st.execute("INSERT IGNORE INTO users VALUES ('admin', 'admin123', 'Admin')");

                // 2. Products Table (Inventory)
                st.execute("CREATE TABLE IF NOT EXISTS products (" +
                        "id INT AUTO_INCREMENT PRIMARY KEY, " +
                        "name VARCHAR(100) NOT NULL, " +
                        "category VARCHAR(50), " +
                        "quantity INT DEFAULT 0, " +
                        "price DOUBLE DEFAULT 0.0, " +
                        "min_stock_level INT DEFAULT 5)");

                // 3. Customers Table
                st.execute("CREATE TABLE IF NOT EXISTS customers (" +
                        "id INT AUTO_INCREMENT PRIMARY KEY, " +
                        "name VARCHAR(100) NOT NULL, " +
                        "phone VARCHAR(20), " +
                        "email VARCHAR(100))");

                // 4. Sales Table
                st.execute("CREATE TABLE IF NOT EXISTS sales (" +
                        "id INT AUTO_INCREMENT PRIMARY KEY, " +
                        "product_id INT, " +
                        "quantity INT, " +
                        "total_price DOUBLE, " +
                        "customer_id INT, " + 
                        "sale_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP, " +
                        "FOREIGN KEY (product_id) REFERENCES products(id))");

                // Try adding column if it doesn't exist (for migration)
                try {
                    st.execute("ALTER TABLE sales ADD COLUMN customer_id INT");
                } catch (SQLException ignored) {} 

                // 5. Expenses Table
                st.execute("CREATE TABLE IF NOT EXISTS expenses (" +
                        "id INT AUTO_INCREMENT PRIMARY KEY, " +
                        "category VARCHAR(50), " +
                        "amount DOUBLE, " +
                        "description VARCHAR(255), " +
                        "expense_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP)");

                System.out.println("Database initialized successfully.");
                
            } catch (SQLException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(null, "Database Init Error: " + e.getMessage());
            }
        }

        public static String validateLogin(String username, String password) {
            String role = null;
            String query = "SELECT role FROM users WHERE username = ? AND password = ?";
            
            try (Connection con = getConnection();
                 PreparedStatement pst = con.prepareStatement(query)) {
                
                pst.setString(1, username);
                pst.setString(2, password);
                
                try (ResultSet rs = pst.executeQuery()) {
                    if (rs.next()) {
                        role = rs.getString("role");
                    }
                }
            } catch (SQLException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(null, "Login Error: " + e.getMessage());
            }
            return role; 
        }

        // --- REGISTRATION ---
        public static boolean registerUser(String username, String password) {
            String query = "INSERT INTO users (username, password, role) VALUES (?, ?, 'User')";
            try (Connection con = getConnection();
                 PreparedStatement pst = con.prepareStatement(query)) {
                pst.setString(1, username);
                pst.setString(2, password);
                pst.executeUpdate();
                return true;
            } catch (SQLException e) {
                e.printStackTrace();
                // Likely duplicate username
                return false;
            }
        }

        // --- INVENTORY METHODS ---
        public static ResultSet getAllProducts() throws SQLException {
            Connection con = getConnection();
            Statement st = con.createStatement();
            return st.executeQuery("SELECT * FROM products");
        }

        public static void addProduct(String name, String category, int quantity, double price, int minStock) throws SQLException {
            String sql = "INSERT INTO products (name, category, quantity, price, min_stock_level) VALUES (?, ?, ?, ?, ?)";
            try (Connection con = getConnection(); PreparedStatement pst = con.prepareStatement(sql)) {
                pst.setString(1, name);
                pst.setString(2, category);
                pst.setInt(3, quantity);
                pst.setDouble(4, price);
                pst.setInt(5, minStock);
                pst.executeUpdate();
            }
        }

        public static void updateProduct(int id, String name, String category, int quantity, double price, int minStock) throws SQLException {
            String sql = "UPDATE products SET name=?, category=?, quantity=?, price=?, min_stock_level=? WHERE id=?";
            try (Connection con = getConnection(); PreparedStatement pst = con.prepareStatement(sql)) {
                pst.setString(1, name);
                pst.setString(2, category);
                pst.setInt(3, quantity);
                pst.setDouble(4, price);
                pst.setInt(5, minStock);
                pst.setInt(6, id);
                pst.executeUpdate();
            }
        }

        public static void deleteProduct(int id) throws SQLException {
            String sql = "DELETE FROM products WHERE id=?";
            try (Connection con = getConnection(); PreparedStatement pst = con.prepareStatement(sql)) {
                pst.setInt(1, id);
                pst.executeUpdate();
            }
        }

        // --- SALES METHODS ---
        public static void recordSale(int productId, int qty, double totalPrice, int customerId) throws SQLException {
            // 1. Record Sale
            String saleSql = "INSERT INTO sales (product_id, quantity, total_price, customer_id) VALUES (?, ?, ?, ?)";
            
            // 2. Update Stock
            String stockSql = "UPDATE products SET quantity = quantity - ? WHERE id = ?";
            
            Connection con = getConnection();
            try {
                con.setAutoCommit(false); // Transaction

                // Insert Sale
                try (PreparedStatement pst = con.prepareStatement(saleSql)) {
                    pst.setInt(1, productId);
                    pst.setInt(2, qty);
                    pst.setDouble(3, totalPrice);
                    if (customerId > 0) pst.setInt(4, customerId);
                    else pst.setNull(4, java.sql.Types.INTEGER);
                    pst.executeUpdate();
                }

                // Update Stock
                try (PreparedStatement pst = con.prepareStatement(stockSql)) {
                    pst.setInt(1, qty);
                    pst.setInt(2, productId);
                    pst.executeUpdate();
                }

                con.commit();
            } catch (SQLException e) {
                con.rollback();
                throw e;
            } finally {
                con.setAutoCommit(true);
                con.close();
            }
        }

        // --- EXPENSE METHODS ---
        public static void addExpense(String category, double amount, String description) throws SQLException {
            String sql = "INSERT INTO expenses (category, amount, description) VALUES (?, ?, ?)";
            try (Connection con = getConnection(); PreparedStatement pst = con.prepareStatement(sql)) {
                pst.setString(1, category);
                pst.setDouble(2, amount);
                pst.setString(3, description);
                pst.executeUpdate();
            }
        }

        public static ResultSet getAllExpenses() throws SQLException {
            Connection con = getConnection();
            Statement st = con.createStatement();
            return st.executeQuery("SELECT * FROM expenses ORDER BY expense_date DESC");
        }

        // --- CUSTOMER METHODS ---
        public static void addCustomer(String name, String phone, String email) throws SQLException {
            String sql = "INSERT INTO customers (name, phone, email) VALUES (?, ?, ?)";
            try (Connection con = getConnection(); PreparedStatement pst = con.prepareStatement(sql)) {
                pst.setString(1, name);
                pst.setString(2, phone);
                pst.setString(3, email);
                pst.executeUpdate();
            }
        }

        public static ResultSet getAllCustomers() throws SQLException {
            Connection con = getConnection();
            Statement st = con.createStatement();
            return st.executeQuery("SELECT * FROM customers");
        }

        // --- REPORTING & STATS ---
        public static double getTodaySalesTotal() throws SQLException {
            double total = 0;
            String sql = "SELECT SUM(total_price) FROM sales WHERE DATE(sale_date) = CURDATE()";
            try (Connection con = getConnection(); Statement st = con.createStatement(); ResultSet rs = st.executeQuery(sql)) {
                if (rs.next()) {
                    total = rs.getDouble(1);
                }
            }
            return total;
        }

        public static int getLowStockCount() throws SQLException {
            int count = 0;
            String sql = "SELECT COUNT(*) FROM products WHERE quantity <= min_stock_level";
            try (Connection con = getConnection(); Statement st = con.createStatement(); ResultSet rs = st.executeQuery(sql)) {
                if (rs.next()) {
                    count = rs.getInt(1);
                }
            }
            return count;
        }

        public static ResultSet getSalesReport() throws SQLException {
            Connection con = getConnection();
            Statement st = con.createStatement();
            // Simple join to show Product Name
            String sql = "SELECT s.id, p.name, s.quantity, s.total_price, s.sale_date " +
                         "FROM sales s JOIN products p ON s.product_id = p.id " +
                         "ORDER BY s.sale_date DESC";
            return st.executeQuery(sql);
        }
    }

    // ==========================================
    // LOGIN FRAME
    // ==========================================
    public static class LoginFrame extends JFrame {
        
        // Components
        private JLabel lblTitle, lblUser, lblPass;
        private JTextField txtUser;
        private JPasswordField txtPass;
        private JButton btnLogin, btnCancel;
    
        public LoginFrame() {
            // Frame Setup
            setTitle("SmartBizz - Login");
            setSize(400, 300);
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            setLocationRelativeTo(null); // Center screen
            setLayout(null); // NULL LAYOUT AS REQUESTED
            setResizable(false);
    
            initUI();
        }
    
        private void initUI() {
            // Title
            lblTitle = new JLabel("SmartBizz Login");
            lblTitle.setFont(new java.awt.Font("Arial", java.awt.Font.BOLD, 20));
            lblTitle.setBounds(120, 20, 200, 30);
            add(lblTitle);
    
            // Username Label & Field
            lblUser = new JLabel("Username:");
            lblUser.setBounds(50, 80, 80, 25);
            add(lblUser);
    
            txtUser = new JTextField();
            txtUser.setBounds(140, 80, 200, 25);
            add(txtUser);
    
            // Password Label & Field
            lblPass = new JLabel("Password:");
            lblPass.setBounds(50, 120, 80, 25);
            add(lblPass);
    
            txtPass = new JPasswordField();
            txtPass.setBounds(140, 120, 200, 25);
            add(txtPass);
    
            // Login Button
            btnLogin = new JButton("Login");
            btnLogin.setBounds(140, 170, 90, 30);
            add(btnLogin);
            
            // Cancel Button
            btnCancel = new JButton("Cancel");
            btnCancel.setBounds(250, 170, 90, 30);
            add(btnCancel);
            
            JButton btnRegister = new JButton("Register New User");
            btnRegister.setBounds(140, 210, 200, 30);
            add(btnRegister);
            
            btnRegister.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    new RegisterFrame().setVisible(true);
                }
            });
    
            // Action Listeners (Anonymous Inner Class Style as requested)
            btnLogin.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    String user = txtUser.getText();
                    String pass = new String(txtPass.getPassword());
    
                    if (user.isEmpty() || pass.isEmpty()) {
                        JOptionPane.showMessageDialog(null, "Please enter all fields.");
                        return;
                    }
    
                    // Authenticate
                    String role = DatabaseHelper.validateLogin(user, pass);
                    if (role != null) {
                        // JOptionPane.showMessageDialog(null, "Login Successful! Role: " + role); // Optional
                        dispose(); // Close Login Frame
                        new MainFrame(role).setVisible(true);
                    } else {
                        JOptionPane.showMessageDialog(null, "Invalid Username or Password.");
                    }
                }
            });
    
            btnCancel.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    System.exit(0);
                }
            });
        }
    }

    // ==========================================
    // REGISTER FRAME
    // ==========================================
    public static class RegisterFrame extends JFrame {
    
        private JTextField txtUser;
        private JPasswordField txtPass, txtConfirm;
        private JButton btnRegister, btnBack;
    
        public RegisterFrame() {
            setTitle("SmartBizz - Register User");
            setSize(400, 350);
            setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            setLocationRelativeTo(null);
            setLayout(null);
            setResizable(false);
    
            initUI();
        }
    
        private void initUI() {
            JLabel lblTitle = new JLabel("Create New Account");
            lblTitle.setFont(new java.awt.Font("Arial", java.awt.Font.BOLD, 18));
            lblTitle.setBounds(100, 20, 200, 30);
            add(lblTitle);
    
            JLabel lblUser = new JLabel("Username:");
            lblUser.setBounds(50, 70, 80, 25);
            add(lblUser);
    
            txtUser = new JTextField();
            txtUser.setBounds(140, 70, 200, 25);
            add(txtUser);
    
            JLabel lblPass = new JLabel("Password:");
            lblPass.setBounds(50, 110, 80, 25);
            add(lblPass);
    
            txtPass = new JPasswordField();
            txtPass.setBounds(140, 110, 200, 25);
            add(txtPass);
    
            JLabel lblConfirm = new JLabel("Confirm:");
            lblConfirm.setBounds(50, 150, 80, 25);
            add(lblConfirm);
    
            txtConfirm = new JPasswordField();
            txtConfirm.setBounds(140, 150, 200, 25);
            add(txtConfirm);
    
            btnRegister = new JButton("Register");
            btnRegister.setBounds(140, 200, 100, 30);
            add(btnRegister);
    
            btnBack = new JButton("Back");
            btnBack.setBounds(250, 200, 80, 30);
            add(btnBack);
    
            btnRegister.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    String user = txtUser.getText();
                    String pass = new String(txtPass.getPassword());
                    String confirm = new String(txtConfirm.getPassword());
    
                    if (user.isEmpty() || pass.isEmpty()) {
                        JOptionPane.showMessageDialog(null, "Please fill all fields");
                        return;
                    }
                    if (!pass.equals(confirm)) {
                        JOptionPane.showMessageDialog(null, "Passwords do not match");
                        return;
                    }
    
                    if (DatabaseHelper.registerUser(user, pass)) {
                        JOptionPane.showMessageDialog(null, "Registration Successful! You can now login.");
                        dispose();
                    } else {
                        JOptionPane.showMessageDialog(null, "Username already exists or Error.");
                    }
                }
            });
    
            btnBack.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    dispose();
                }
            });
        }
    }

    // ==========================================
    // MAIN FRAME
    // ==========================================
    public static class MainFrame extends JFrame {
        
        private String userRole;
        private JLabel lblWelcome, lblTotalSales, lblLowStock;
        private JButton btnInventory, btnSales, btnExpenses, btnCustomers, btnReports, btnLogout;
    
        public MainFrame(String role) {
            this.userRole = role;
            
            setTitle("SmartBizz - Dashboard");
            setSize(900, 700); // Slightly bigger
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            setLocationRelativeTo(null);
            setLayout(null); 
            
           
            getContentPane().setBackground(new Color(44, 62, 80)); // Dark Blue-Grey theme
            
            initUI();
        }
    
        private void initUI() {
         
            lblWelcome = new JLabel("Welcome to SmartBizz, " + userRole, SwingConstants.CENTER);
            lblWelcome.setFont(new Font("Segoe UI", Font.BOLD, 32));
            lblWelcome.setForeground(new Color(236, 240, 241)); // White-ish
            lblWelcome.setBounds(100, 30, 700, 50);
            add(lblWelcome);
    
            
            JPanel statsPanel = new JPanel();
            statsPanel.setLayout(null);
            statsPanel.setBounds(150, 100, 600, 100);
            statsPanel.setBackground(new Color(236, 240, 241)); // Light background
            add(statsPanel);
            
            lblTotalSales = new JLabel("Today's Sales: $0.00", SwingConstants.CENTER);
            lblTotalSales.setFont(new Font("Segoe UI", Font.BOLD, 20));
            lblTotalSales.setForeground(new Color(39, 174, 96)); // Green
            lblTotalSales.setBounds(10, 20, 280, 60);
            statsPanel.add(lblTotalSales);
    
            lblLowStock = new JLabel("Low Stock Items: 0", SwingConstants.CENTER);
            lblLowStock.setFont(new Font("Segoe UI", Font.BOLD, 20));
            lblLowStock.setForeground(new Color(192, 57, 43)); // Red
            lblLowStock.setBounds(310, 20, 280, 60);
            statsPanel.add(lblLowStock);
    
            // --- BUTTONS (Centered) ---
            int startY = 240;
            int gap = 20;
            int btnWidth = 250;
            int btnHeight = 60; // Bigger buttons
            int centerX = (900 - btnWidth) / 2; // Center horizontally
    
            // Inventory
            btnInventory = createButton("Inventory", centerX, startY, new Color(52, 152, 219)); // Blue
            startY += btnHeight + gap;
    
            // Sales
            btnSales = createButton("Sales (POS)", centerX, startY, new Color(46, 204, 113)); // Green
            startY += btnHeight + gap;
    
            // Expenses
            btnExpenses = createButton("Expenses", centerX, startY, new Color(231, 76, 60)); // Red
            startY += btnHeight + gap;
    
            // Customers
            btnCustomers = createButton("Customers", centerX, startY, new Color(155, 89, 182)); // Purple
            startY += btnHeight + gap;
    
            // Reports
            btnReports = createButton("Reports", centerX, startY, new Color(241, 196, 15)); // Yellow/Orange
            
            // Logout (Bottom Right)
            btnLogout = createButton("Logout", 750, 600, new Color(149, 165, 166)); // Grey
            btnLogout.setBounds(750, 600, 100, 40); // Override size for logout
            btnLogout.setFont(new Font("Segoe UI", Font.BOLD, 14));
    
            // --- ROLE RESTRICTIONS ---
            if ("User".equalsIgnoreCase(userRole)) {
                // Disable everything except Inventory
                btnSales.setEnabled(false);
                btnSales.setBackground(Color.GRAY);
                
                btnExpenses.setEnabled(false);
                btnExpenses.setBackground(Color.GRAY);
                
                btnCustomers.setEnabled(false);
                btnCustomers.setBackground(Color.GRAY);
                
                btnReports.setEnabled(false);
                btnReports.setBackground(Color.GRAY);
                
                // Inventory enabled, but will be read-only (handled in InventoryFrame)
            }
    
            // --- ACTION LISTENERS ---
            btnLogout.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    dispose();
                    new LoginFrame().setVisible(true);
                }
            });
            
            btnInventory.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                     new InventoryFrame(userRole).setVisible(true);
                }
            });
    
            btnSales.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    new SalesFrame().setVisible(true);
                }
            });
            
            btnExpenses.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    new ExpenseFrame().setVisible(true);
                }
            });
    
            btnCustomers.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    new CustomerFrame().setVisible(true);
                }
            });
    
            btnReports.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    new ReportFrame().setVisible(true);
                }
            });
    
            refreshStats();
        }
    
        private void refreshStats() {
            try {
                double sales = DatabaseHelper.getTodaySalesTotal();
                int lowStock = DatabaseHelper.getLowStockCount();
                
                lblTotalSales.setText("Today's Sales: $" + String.format("%.2f", sales));
                lblLowStock.setText("Low Stock Items: " + lowStock);
                
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    
        private JButton createButton(String text, int x, int y, Color bg) {
            JButton btn = new JButton(text);
            btn.setBounds(x, y, 250, 60);
            btn.setFont(new Font("Arial", Font.BOLD, 18));
            btn.setBackground(bg);
            btn.setForeground(Color.WHITE);
            btn.setFocusPainted(false);
            btn.setBorderPainted(false); 
            add(btn);
            return btn;
        }
    }

    // ==========================================
    // INVENTORY FRAME
    // ==========================================
    public static class InventoryFrame extends JFrame {
    
        private JTable table;
        private String userRole; // Add role
        private DefaultTableModel model;
        private JTextField txtName, txtCategory, txtQty, txtPrice, txtMinStock;
        private JButton btnAdd, btnUpdate, btnDelete, btnClear, btnBack;
        private int selectedId = -1; // To hold ID for update/delete
    
        public InventoryFrame() {
            this("Admin"); // Default compatibility
        }
    
        public InventoryFrame(String role) { // New Constructor
            this.userRole = role;
            setTitle("SmartBizz - Inventory Management");
            setSize(900, 600);
            setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // Don't exit app, just close window
            setLocationRelativeTo(null);
            setLayout(null); // NULL LAYOUT
            
            initUI();
            loadData();
        }
    
        private void initUI() {
            // --- INPUT FIELDS (Top) ---
            JLabel lblName = new JLabel("Product Name:");
            lblName.setBounds(20, 20, 100, 25);
            add(lblName);
            
            txtName = new JTextField();
            txtName.setBounds(120, 20, 200, 25);
            add(txtName);
    
            JLabel lblCategory = new JLabel("Category:");
            lblCategory.setBounds(340, 20, 80, 25);
            add(lblCategory);
            
            txtCategory = new JTextField();
            txtCategory.setBounds(410, 20, 150, 25);
            add(txtCategory);
            
            JLabel lblQty = new JLabel("Quantity:");
            lblQty.setBounds(20, 60, 100, 25);
            add(lblQty);
            
            txtQty = new JTextField();
            txtQty.setBounds(120, 60, 100, 25);
            add(txtQty);
            
            JLabel lblPrice = new JLabel("Price:");
            lblPrice.setBounds(240, 60, 60, 25);
            add(lblPrice);
            
            txtPrice = new JTextField();
            txtPrice.setBounds(290, 60, 100, 25);
            add(txtPrice);
            
            JLabel lblMin = new JLabel("Min Stock:");
            lblMin.setBounds(410, 60, 80, 25);
            add(lblMin);
            
            txtMinStock = new JTextField();
            txtMinStock.setBounds(480, 60, 80, 25);
            add(txtMinStock);
    
            // --- BUTTONS ---
            btnAdd = new JButton("Add");
            btnAdd.setBounds(600, 20, 100, 30);
            add(btnAdd);
    
            btnUpdate = new JButton("Update");
            btnUpdate.setBounds(600, 60, 100, 30);
            add(btnUpdate);
            
            btnDelete = new JButton("Delete");
            btnDelete.setBounds(720, 20, 100, 30);
            add(btnDelete);
            
            
            btnClear = new JButton("Clear");
            btnClear.setBounds(720, 60, 100, 30); // Aligned with Update, below Delete
            add(btnClear);
            
            // Disable editing for Users
            if("User".equalsIgnoreCase(userRole)) {
                // Hide Admin Buttons
                btnAdd.setVisible(false);
                btnUpdate.setVisible(false);
                btnDelete.setVisible(false);
                
                // Reposition Clear Button to primary spot
                btnClear.setBounds(600, 20, 100, 30);
                
                JLabel lblReadOnly = new JLabel("(Read Only Mode)");
                lblReadOnly.setForeground(java.awt.Color.RED);
                lblReadOnly.setBounds(20, 10, 150, 20);
                add(lblReadOnly);
            } else {
                // Admin Role: Ensure visibility (default)
            }
    
            // Table Code ...
            
            btnBack = new JButton("Back");
            btnBack.setBounds(720, 520, 100, 30);
            add(btnBack);
    
            // --- TABLE ---
            String[] columns = {"ID", "Name", "Category", "Quantity", "Price", "Min Stock"};
            model = new DefaultTableModel(columns, 0);
            table = new JTable(model);
            JScrollPane scrollPane = new JScrollPane(table);
            scrollPane.setBounds(20, 120, 840, 380);
            add(scrollPane);
            
            // --- LISTENERS ---
            
            // Table Selection Listener
            table.addMouseListener(new MouseAdapter() {
                public void mouseClicked(MouseEvent e) {
                    int row = table.getSelectedRow();
                    if (row != -1) {
                        selectedId = (int) model.getValueAt(row, 0);
                        txtName.setText(model.getValueAt(row, 1).toString());
                        txtCategory.setText(model.getValueAt(row, 2).toString());
                        txtQty.setText(model.getValueAt(row, 3).toString());
                        txtPrice.setText(model.getValueAt(row, 4).toString());
                        txtMinStock.setText(model.getValueAt(row, 5).toString());
                    }
                }
            });
    
            btnAdd.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    try {
                        String name = txtName.getText();
                        String cat = txtCategory.getText();
                        int qty = Integer.parseInt(txtQty.getText());
                        double price = Double.parseDouble(txtPrice.getText());
                        int min = Integer.parseInt(txtMinStock.getText());
                        
                        DatabaseHelper.addProduct(name, cat, qty, price, min);
                        loadData();
                        clearFields();
                        JOptionPane.showMessageDialog(null, "Product Added!");
                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage());
                    }
                }
            });
    
            btnUpdate.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    if (selectedId == -1) { 
                        JOptionPane.showMessageDialog(null, "Select a product to update"); 
                        return; 
                    }
                    try {
                        String name = txtName.getText();
                        String cat = txtCategory.getText();
                        int qty = Integer.parseInt(txtQty.getText());
                        double price = Double.parseDouble(txtPrice.getText());
                        int min = Integer.parseInt(txtMinStock.getText());
                        
                        DatabaseHelper.updateProduct(selectedId, name, cat, qty, price, min);
                        loadData();
                        clearFields();
                        JOptionPane.showMessageDialog(null, "Product Updated!");
                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage());
                    }
                }
            });
    
            btnDelete.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    if (selectedId == -1) { 
                        JOptionPane.showMessageDialog(null, "Select a product to delete"); 
                        return; 
                    }
                    int confirm = JOptionPane.showConfirmDialog(null, "Are you sure?");
                    if (confirm == JOptionPane.YES_OPTION) {
                        try {
                            DatabaseHelper.deleteProduct(selectedId);
                        } catch (SQLException ex) {
                            Logger.getLogger(InventoryFrame.class.getName()).log(Level.SEVERE, null, ex);
                        }
                        loadData();
                        clearFields();
                    }
                }
            });
            
            btnClear.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    clearFields();
                }
            });
            
            btnBack.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    dispose();
                }
            });
        }
    
        private void loadData() {
            try {
                model.setRowCount(0);
                ResultSet rs = DatabaseHelper.getAllProducts();
                while (rs.next()) {
                    Vector<Object> row = new Vector<>();
                    row.add(rs.getInt("id"));
                    row.add(rs.getString("name"));
                    row.add(rs.getString("category"));
                    row.add(rs.getInt("quantity"));
                    row.add(rs.getDouble("price"));
                    row.add(rs.getInt("min_stock_level"));
                    model.addRow(row);
                }
                rs.close(); 
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        
        private void clearFields() {
            txtName.setText("");
            txtCategory.setText("");
            txtQty.setText("");
            txtPrice.setText("");
            txtMinStock.setText("");
            selectedId = -1;
            table.clearSelection();
        }
    }

    // ==========================================
    // SALES FRAME
    // ==========================================
    public static class SalesFrame extends JFrame {
        
        // UI Components
        private JComboBox<String> cbProducts;
        private JComboBox<CustomerItem> cbCustomers;
        private JTextField txtQty;
        private JButton btnAddCart, btnCheckout, btnBack;
        private JTable cartTable;
        private DefaultTableModel cartModel;
        private JLabel lblTotal;
        
        // Data
        private ArrayList<ProductItem> productList = new ArrayList<>();
        private double currentTotal = 0.0;
        
        // Inner class for product mapping
        private class ProductItem {
            int id;
            String name;
            double price;
            int stock;
            
            public ProductItem(int id, String name, double price, int stock) {
                this.id = id;
                this.name = name;
                this.price = price;
                this.stock = stock;
            }
            @Override
            public String toString() { return name + " ($" + price + ") - Stock: " + stock; }
        }
        
        // Inner class for customer
        private class CustomerItem {
            int id;
            String name;
            public CustomerItem(int id, String name) { this.id = id; this.name = name; }
            @Override public String toString() { return name; }
        }
    
        public SalesFrame() {
            setTitle("SmartBizz - Sales (POS)");
            setSize(800, 650);
            setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            setLocationRelativeTo(null);
            setLayout(null);
            
            initUI();
            loadProducts();
            loadCustomers();
        }
    
        private void initUI() {
            JLabel lblProd = new JLabel("Product:");
            lblProd.setBounds(20, 20, 60, 25);
            add(lblProd);
            
            cbProducts = new JComboBox<>();
            cbProducts.setBounds(90, 20, 250, 25);
            add(cbProducts);
            
            JLabel lblQty = new JLabel("Qty:");
            lblQty.setBounds(350, 20, 40, 25);
            add(lblQty);
            
            txtQty = new JTextField();
            txtQty.setBounds(390, 20, 50, 25);
            add(txtQty);
            
            // Use field, not local variable
            btnAddCart = new JButton("Add");
            btnAddCart.setBounds(450, 20, 80, 25);
            add(btnAddCart);
            
            JLabel lblCust = new JLabel("Customer:");
            lblCust.setBounds(550, 20, 70, 25);
            add(lblCust);
            
            cbCustomers = new JComboBox<>();
            cbCustomers.setBounds(620, 20, 150, 25);
            add(cbCustomers);
            
            // Cart Table
            String[] cols = {"Product ID", "Name", "Qty", "Price", "Total"};
            cartModel = new DefaultTableModel(cols, 0);
            cartTable = new JTable(cartModel);
            JScrollPane scroll = new JScrollPane(cartTable);
            scroll.setBounds(20, 70, 740, 350);
            add(scroll);
            
            // Footer
            lblTotal = new JLabel("Total: $0.00");
            lblTotal.setFont(new java.awt.Font("Arial", java.awt.Font.BOLD, 20));
            lblTotal.setBounds(20, 440, 300, 30);
            add(lblTotal);
            
            btnCheckout = new JButton("Checkout");
            btnCheckout.setFont(new java.awt.Font("Arial", java.awt.Font.BOLD, 14));
            btnCheckout.setBounds(600, 440, 160, 40);
            add(btnCheckout);
            
            btnBack = new JButton("Back");
            btnBack.setBounds(20, 500, 100, 30);
            add(btnBack);
    
            // --- LISTENERS ---
            
            btnAddCart.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    addToCart();
                }
            });
            
            btnCheckout.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    try {
                        checkout();
                    } catch (SQLException ex) {
                        Logger.getLogger(SalesFrame.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            });
            
            btnBack.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    dispose();
                }
            });
        }
    
        private void loadProducts() {
            productList.clear();
            cbProducts.removeAllItems();
            try {
                ResultSet rs = DatabaseHelper.getAllProducts();
                while (rs.next()) {
                    ProductItem item = new ProductItem(
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getDouble("price"),
                        rs.getInt("quantity")
                    );
                    productList.add(item);
                    cbProducts.addItem(item.toString());
                }
                rs.getStatement().getConnection().close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    
        private void loadCustomers() {
            cbCustomers.addItem(new CustomerItem(0, "Walk-in Customer"));
            try {
                ResultSet rs = DatabaseHelper.getAllCustomers();
                while (rs.next()) {
                    cbCustomers.addItem(new CustomerItem(rs.getInt("id"), rs.getString("name")));
                }
                rs.getStatement().getConnection().close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    
        private void addToCart() {
            int idx = cbProducts.getSelectedIndex();
            if (idx < 0) return;
            
            String qtyStr = txtQty.getText();
            if (qtyStr.isEmpty()) { JOptionPane.showMessageDialog(null, "Enter Quantity"); return; }
            
            try {
                int qty = Integer.parseInt(qtyStr);
                ProductItem item = productList.get(idx);
                
                if (qty > item.stock) {
                    JOptionPane.showMessageDialog(null, "Not enough stock! Available: " + item.stock);
                    return;
                }
                
                double lineTotal = qty * item.price;
                
                // Add to model
                cartModel.addRow(new Object[]{item.id, item.name, qty, item.price, lineTotal});
                
                // Update UI Total
                currentTotal += lineTotal;
                lblTotal.setText("Total: $" + String.format("%.2f", currentTotal));
                
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Invalid Quantity");
            }
        }
    
        private void checkout() throws SQLException {
            if (cartModel.getRowCount() == 0) {
                JOptionPane.showMessageDialog(null, "Cart is empty!");
                return;
            }
            
            CustomerItem selectedCust = (CustomerItem) cbCustomers.getSelectedItem();
            int custId = selectedCust.id;
    
            for (int i = 0; i < cartModel.getRowCount(); i++) {
                int pid = (int) cartModel.getValueAt(i, 0);
                int qty = (int) cartModel.getValueAt(i, 2);
                double total = (double) cartModel.getValueAt(i, 4);
                
                DatabaseHelper.recordSale(pid, qty, total, custId);
            }
            JOptionPane.showMessageDialog(null, "Sale Recorded Successfully!");
            cartModel.setRowCount(0);
            currentTotal = 0;
            lblTotal.setText("Total: $0.00");
            loadProducts();
        }
    }

    // ==========================================
    // EXPENSE FRAME
    // ==========================================
    public static class ExpenseFrame extends JFrame {
    
        private JComboBox<String> cbCategory;
        private JTextField txtAmount, txtDesc;
        private JButton btnAdd, btnBack;
        private JTable table;
        private DefaultTableModel model;
    
        public ExpenseFrame() {
            setTitle("SmartBizz - Expense Management");
            setSize(800, 500);
            setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            setLocationRelativeTo(null);
            setLayout(null);
    
            initUI();
            loadData();
        }
    
        private void initUI() {
            JLabel lblCat = new JLabel("Category:");
            lblCat.setBounds(20, 20, 80, 25);
            add(lblCat);
    
            String[] categories = {"Rent", "Utilities", "Salaries", "Maintenance", "Other"};
            cbCategory = new JComboBox<>(categories);
            cbCategory.setBounds(100, 20, 150, 25);
            add(cbCategory);
    
            JLabel lblAmt = new JLabel("Amount:");
            lblAmt.setBounds(270, 20, 60, 25);
            add(lblAmt);
    
            txtAmount = new JTextField();
            txtAmount.setBounds(330, 20, 100, 25);
            add(txtAmount);
    
            JLabel lblDesc = new JLabel("Description:");
            lblDesc.setBounds(450, 20, 80, 25);
            add(lblDesc);
    
            txtDesc = new JTextField();
            txtDesc.setBounds(530, 20, 150, 25);
            add(txtDesc);
    
            btnAdd = new JButton("Add Expense");
            btnAdd.setBounds(690, 20, 120, 25); // Adjusted width/pos
            add(btnAdd);
    
            // Table
            String[] cols = {"ID", "Category", "Amount", "Description", "Date"};
            model = new DefaultTableModel(cols, 0);
            table = new JTable(model);
            JScrollPane scroll = new JScrollPane(table);
            scroll.setBounds(20, 60, 740, 350);
            add(scroll);
    
            btnBack = new JButton("Back");
            btnBack.setBounds(20, 420, 100, 30);
            add(btnBack);
    
            // Listeners
            btnAdd.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    try {
                        String cat = (String) cbCategory.getSelectedItem();
                        double amt = Double.parseDouble(txtAmount.getText());
                        String desc = txtDesc.getText();
    
                        DatabaseHelper.addExpense(cat, amt, desc);
                        loadData();
                        txtAmount.setText("");
                        txtDesc.setText("");
                        JOptionPane.showMessageDialog(null, "Expense Added!");
                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(null, "Invalid Amount");
                    } catch (SQLException ex) {
                        Logger.getLogger(ExpenseFrame.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            });
    
            btnBack.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    dispose();
                }
            });
        }
    
        private void loadData() {
            model.setRowCount(0);
            try {
                ResultSet rs = DatabaseHelper.getAllExpenses();
                while (rs.next()) {
                    Vector<Object> row = new Vector<>();
                    row.add(rs.getInt("id"));
                    row.add(rs.getString("category"));
                    row.add(rs.getDouble("amount"));
                    row.add(rs.getString("description"));
                    row.add(rs.getTimestamp("expense_date"));
                    model.addRow(row);
                }
                rs.getStatement().getConnection().close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    // ==========================================
    // CUSTOMER FRAME
    // ==========================================
    public static class CustomerFrame extends JFrame {
        
        private JTextField txtName, txtPhone, txtEmail;
        private JButton btnAdd, btnBack;
        private JTable table;
        private DefaultTableModel model;
    
        public CustomerFrame() {
            setTitle("SmartBizz - Customer Management");
            setSize(800, 500);
            setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            setLocationRelativeTo(null);
            setLayout(null);
    
            initUI();
            loadData();
        }
    
        private void initUI() {
            JLabel lblName = new JLabel("Name:");
            lblName.setBounds(20, 20, 80, 25);
            add(lblName);
            
            txtName = new JTextField();
            txtName.setBounds(70, 20, 150, 25);
            add(txtName);
            
            JLabel lblPhone = new JLabel("Phone:");
            lblPhone.setBounds(240, 20, 60, 25);
            add(lblPhone);
            
            txtPhone = new JTextField();
            txtPhone.setBounds(300, 20, 120, 25);
            add(txtPhone);
            
            JLabel lblEmail = new JLabel("Email:");
            lblEmail.setBounds(440, 20, 60, 25);
            add(lblEmail);
            
            txtEmail = new JTextField();
            txtEmail.setBounds(500, 20, 150, 25);
            add(txtEmail);
            
            btnAdd = new JButton("Add Customer");
            btnAdd.setBounds(660, 20, 120, 25);
            add(btnAdd);
    
            // Table
            String[] cols = {"ID", "Name", "Phone", "Email"};
            model = new DefaultTableModel(cols, 0);
            table = new JTable(model);
            JScrollPane scroll = new JScrollPane(table);
            scroll.setBounds(20, 60, 740, 350);
            add(scroll);
    
            btnBack = new JButton("Back");
            btnBack.setBounds(20, 420, 100, 30);
            add(btnBack);
    
            // Listeners
            btnAdd.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    try {
                        String name = txtName.getText();
                        String phone = txtPhone.getText();
                        String email = txtEmail.getText();
                        
                        if(name.isEmpty()) { JOptionPane.showMessageDialog(null, "Name Required"); return; }
    
                        DatabaseHelper.addCustomer(name, phone, email);
                        loadData();
                        txtName.setText("");
                        txtPhone.setText("");
                        txtEmail.setText("");
                        JOptionPane.showMessageDialog(null, "Customer Added!");
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                    }
                }
            });
    
            btnBack.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    dispose();
                }
            });
        }
    
        private void loadData() {
            model.setRowCount(0);
            try {
                ResultSet rs = DatabaseHelper.getAllCustomers();
                while (rs.next()) {
                    Vector<Object> row = new Vector<>();
                    row.add(rs.getInt("id"));
                    row.add(rs.getString("name"));
                    row.add(rs.getString("phone"));
                    row.add(rs.getString("email"));
                    model.addRow(row);
                }
                rs.getStatement().getConnection().close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    // ==========================================
    // REPORT FRAME
    // ==========================================
    public static class ReportFrame extends JFrame {
    
        private JTable table;
        private DefaultTableModel model;
        private JButton btnClose;
    
        public ReportFrame() {
            setTitle("SmartBizz - Reports");
            setSize(800, 500);
            setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            setLocationRelativeTo(null);
            setLayout(null);
    
            initUI();
            loadData();
        }
    
        private void initUI() {
            JLabel lblTitle = new JLabel("Sales Report");
            lblTitle.setFont(new java.awt.Font("Arial", java.awt.Font.BOLD, 18));
            lblTitle.setBounds(20, 20, 200, 30);
            add(lblTitle);
    
            // Table
            String[] cols = {"Sale ID", "Product", "Qty", "Total Price", "Date"};
            model = new DefaultTableModel(cols, 0);
            table = new JTable(model);
            JScrollPane scroll = new JScrollPane(table);
            scroll.setBounds(20, 60, 740, 350);
            add(scroll);
    
            btnClose = new JButton("Close");
            btnClose.setBounds(20, 420, 100, 30);
            add(btnClose);
    
            btnClose.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    dispose();
                }
            });
        }
    
        private void loadData() {
            model.setRowCount(0);
            try {
                ResultSet rs = DatabaseHelper.getSalesReport();
                while (rs.next()) {
                    Vector<Object> row = new Vector<>();
                    row.add(rs.getInt("id"));
                    row.add(rs.getString("name"));
                    row.add(rs.getString("quantity"));
                    row.add(rs.getDouble("total_price"));
                    row.add(rs.getTimestamp("sale_date"));
                    model.addRow(row);
                }
                rs.getStatement().getConnection().close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

}
